package drivers.util;

public interface PathUtil {
    String CHROME_DRIVER= "D:\\seleniumeg\\chromedriver_win32\\chromedriver.exe";
    String FIREFOX_DRIVER="";
    String EDGE_DRIVER="";
}
